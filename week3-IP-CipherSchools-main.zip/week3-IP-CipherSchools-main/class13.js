let a=13;
let b= "18";
let c=3.8;
console.log("a:",++a);
// console.log("b:",b++);
// console.log("b:",b);
console.log("c:",c);

// let result =a%b/c;
// let result =a**b/c;
let result =a+b;

console.log("result:",result);
if(a>b){
    console.log("yes");
}else{
    console.log("No");
}


if(a==b){
    console.log("yes");
}else{
    console.log("No");
}

if(a===b){
    console.log("yes");
}else{
    console.log("No");
}
if(a!=b){
    console.log("yes");
}else{
    console.log("No");
}